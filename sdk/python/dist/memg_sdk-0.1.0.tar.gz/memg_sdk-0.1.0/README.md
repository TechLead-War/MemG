# MemG Python SDK

Python SDK for [MemG](https://github.com/primetrace/memg) -- a pluggable memory layer for LLM applications.

## Installation

```bash
pip install memg

# With provider extras
pip install memg[openai]
pip install memg[anthropic]
pip install memg[all]
```

## Quick Start

### Proxy Mode (simplest)

Redirect your LLM client through the MemG proxy. No extra code needed beyond wrapping:

```python
from openai import OpenAI
from memg import MemG

client = OpenAI()
client = MemG.wrap(client, entity="user-123", mode="proxy")

# Use as normal -- MemG injects and extracts memories transparently
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "I love hiking in the mountains"}],
)
```

### Client Mode (no proxy needed)

The SDK intercepts calls, queries the MCP server for relevant memories, injects them, and extracts new knowledge:

```python
from openai import OpenAI
from memg import MemG

client = OpenAI()
client = MemG.wrap(client, entity="user-123", mode="client")

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Remember I prefer dark roast coffee"}],
)
```

### Direct Memory Operations

```python
from memg import MemG

m = MemG()

# Add memories
m.add("user-123", "likes coffee")
m.add("user-123", ["works at Acme", "prefers dark mode"])

# Search
results = m.search("user-123", "coffee preferences")
for mem in results.memories:
    print(f"{mem.content} (score={mem.score})")

# List
all_mems = m.list("user-123", type="identity")

# Delete
m.delete("user-123", memory_id="some-uuid")
m.delete_all("user-123")

m.close()
```

## Modes

| Mode | Requires | How it works |
|------|----------|--------------|
| `proxy` | MemG proxy running | Redirects LLM calls through the proxy via `with_options()` |
| `client` | MemG MCP server running | SDK intercepts calls, queries MCP for memories, injects context |

## Configuration

Default URLs:
- MCP server: `http://localhost:8686`
- Proxy: `http://localhost:8787/v1`

Override via constructor or `wrap()`:

```python
m = MemG(mcp_url="http://custom:8686", proxy_url="http://custom:8787/v1")
MemG.wrap(client, mode="proxy", proxy_url="http://custom:8787/v1")
```
